# from django.shortcuts import HttpResponseRedirect
# from adminapp.forms import ShopUserAdminEditForm
# from django.contrib.auth.decorators import login_required
# from django.contrib.auth.decorators import user_passes_test
from django.http.response import HttpResponseRedirect
from django.urls import reverse
from authapp.forms import ShopUserRegisterForm, ShopUserEditForm
from django.shortcuts import render, get_object_or_404
from authapp.models import ShopUser
from adminapp.utils import superuser_required
from adminapp.forms import ShopUserAdminForm


@superuser_required
def user_create(request):
    if request.method == 'POST':
        form = ShopUserAdminForm(request.POST, request.FILES)  # PasswordChangeForm(request.user)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('adminapp:users'))
    else:
        form = ShopUserAdminForm()

    return render(request, 
                'adminapp/user/edit_u.html', 
                context={
                    'title': 'create user',
                    'form': form,
                })



# @login_required   
# @user_passes_test(lambda u: u.is_superuser) 
@superuser_required
def users(request):
    users = ShopUser.objects.all().order_by('id')  # or .filter()

    return render(request, 'adminapp/user/users.html', context={
        'title': 'The_Users',
        'objects':users,
    })

@superuser_required    
def user_update(request, pk):
    user = get_object_or_404(ShopUser, pk=pk)
    if request.method == 'POST':
        form = ShopUserAdminForm(request.POST, request.FILES, instance=user)  # PasswordChangeForm(request.user)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('admianpp:users'))
    else:
        form = ShopUserAdminForm(instance=user)

    return render(request, 
                'adminapp/user/edit_u.html', 
                context={
                    'title': 'edit user',
                    'form': form,
                })

@superuser_required    
def user_delete(request, pk):
    title = 'delete_user'
    user = get_object_or_404(ShopUser, pk=pk)
    if request.method == 'POST':
        # user.delete()
        # make inactive, not delete
        user.is_active = False
        user.save()
        return HttpResponseRedirect(reverse('admianpp:users'))
    else:
        content = {'title':title, 'user_to_delete':user}
        return render(request, 'adminapp/user/delete.html', content)


# def user_create(request):
#     title = 'create_user'

#     if request.method == "POST":
#         user_form = ShopUserRegisterForm(request.POST, reuqest.FILES)
#         if user_form.is_valid():
#             user_form.save()
#             return HttpResponseRedirect(reverse('admianpp:users'))
#     else:
#         user_form = ShopUserRegisterForm()
    
#     content = {'title':title, 'update_form':user_form}

#     return render(request, 'adminapp/user_update.html', content)
# ____________________________________________________