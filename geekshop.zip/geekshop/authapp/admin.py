from django.contrib import admin
from . models import ShopUser

# Register your models here.
admin.site.register(ShopUser)